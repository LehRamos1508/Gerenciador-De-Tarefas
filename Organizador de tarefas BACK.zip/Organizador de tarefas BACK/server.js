const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());


let tarefas = [];


app.post("/tarefas", (req, res) => {
  const { id, descricao, status } = req.body;


  if (!id || !descricao || !status) {
    return res
      .status(400)
      .json({ error: "Campos id, descrição e status são obrigatórios." });
  }

  if (tarefas.find((tarefa) => tarefa.id === id)) {
    return res.status(400).json({ error: "Já existe uma tarefa com este id." });
  }


  tarefas.push({ id, descricao, status });
  res.status(201).json({ message: "Tarefa adicionada com sucesso!" });
});


app.get("/tarefas", (req, res) => {
  res.json(tarefas);
});


app.put("/tarefas/:id", (req, res) => {
  const { id } = req.params;
  const { descricao, status } = req.body;

  const tarefa = tarefas.find((tarefa) => tarefa.id === parseInt(id));

  if (!tarefa) {
    return res.status(404).json({ error: "Tarefa não encontrada." });
  }


  if (descricao) tarefa.descricao = descricao;
  if (status) tarefa.status = status;

  res.json({ message: "Tarefa atualizada com sucesso!" });
});


app.delete("/tarefas/:id", (req, res) => {
  const { id } = req.params;

  const index = tarefas.findIndex((tarefa) => tarefa.id === parseInt(id));

  if (index === -1) {
    return res.status(404).json({ error: "Tarefa não encontrada." });
  }

  tarefas.splice(index, 1); 
  res.json({ message: "Tarefa excluída com sucesso!" });
});


app.get("/tarefas/:id", (req, res) => {
  const { id } = req.params;

  const tarefa = tarefas.find((tarefa) => tarefa.id === parseInt(id));

  if (!tarefa) {
    return res.status(404).json({ error: "Tarefa não encontrada." });
  }

  res.json(tarefa);
});


app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
