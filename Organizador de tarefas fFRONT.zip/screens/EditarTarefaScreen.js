import React, { useState, useCallback } from "react";
import {
  View,
  TextInput,
  Button,
  Text,
  Picker,
  ScrollView,
} from "react-native";
import axios from "axios";
import { globalStyles } from "../styles";

const API_URL = "http://10.68.152.255:3000";

const EditarTarefaScreen = ({ route, navigation }) => {
  const { tarefa } = route.params;
  const [descricao, setDescricao] = useState(tarefa.descricao);
  const [status, setStatus] = useState(tarefa.status.toLowerCase());
  const [error, setError] = useState("");

  const atualizarTarefa = useCallback(async () => {
    if (!descricao.trim()) {
      setError("Descrição não pode estar vazia.");
      return;
    }

    try {
      await axios.put(`${API_URL}/tarefas/${tarefa.id}`, { descricao, status });
      navigation.goBack();
    } catch (error) {
      setError("Erro ao atualizar tarefa: " + error.message);
      console.error(error);
    }
  }, [descricao, status, tarefa.id, navigation]);

  return (
    <ScrollView style={globalStyles.container}>
      <Text style={globalStyles.title}>Editar Tarefa</Text>
      {error ? <Text style={globalStyles.error}>{error}</Text> : null}
      <View style={globalStyles.formGroup}>
        <Text style={globalStyles.label}>Descrição da Tarefa:</Text>
        <TextInput
          style={globalStyles.input}
          placeholder="Digite a descrição da tarefa"
          value={descricao}
          onChangeText={setDescricao}
        />
      </View>
      <View style={globalStyles.formGroup}>
        <Text style={globalStyles.label}>Status:</Text>
        <Picker
          selectedValue={status}
          style={globalStyles.picker}
          onValueChange={(itemValue) => setStatus(itemValue)}
        >
          <Picker.Item label="Pendente" value="pendente" />
          <Picker.Item label="Feito" value="feito" />
        </Picker>
      </View>
      <Button
        title="Atualizar"
        onPress={atualizarTarefa}
        style={globalStyles.button}
      />
    </ScrollView>
  );
};

export default EditarTarefaScreen;
