import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import axios from "axios";

const API_URL = "http://10.68.152.255:3000";

const HomeScreen = ({ navigation }) => {
  const [tarefas, setTarefas] = useState([]);
  const [filtro, setFiltro] = useState(null);

  const buscarTarefas = () => {
    axios
      .get(`${API_URL}/tarefas`)
      .then((response) => setTarefas(response.data))
      .catch((error) => console.error(error));
  };

  useEffect(() => {
    buscarTarefas();

    const unsubscribe = navigation.addListener("focus", () => {
      buscarTarefas();
    });

    return unsubscribe;
  }, [navigation]);

  const deletarTarefa = (id) => {
    axios
      .delete(`${API_URL}/tarefas/${id}`)
      .then(() => setTarefas(tarefas.filter((tarefa) => tarefa.id !== id)))
      .catch((error) => console.error(error));
  };

  const tarefasFiltradas = filtro
    ? tarefas.filter((tarefa) => tarefa.status.toLowerCase() === filtro)
    : tarefas;

  return (
    <View style={styles.container}>
      <View style={styles.filtroContainer}>
        <TouchableOpacity
          style={[styles.botaoFiltro, filtro === null && styles.botaoAtivo]}
          onPress={() => setFiltro(null)}
        >
          <Text style={styles.textoBotao}>📝 Todos</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.botaoFiltro,
            filtro === "pendente" && styles.botaoAtivo,
          ]}
          onPress={() => setFiltro("pendente")}
        >
          <Text style={styles.textoBotao}>⏰ Pendentes</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.botaoFiltro, filtro === "feito" && styles.botaoAtivo]}
          onPress={() => setFiltro("feito")}
        >
          <Text style={styles.textoBotao}>✅ Feito</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={tarefasFiltradas}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text
              style={{
                color: item.status.toLowerCase() === "feito" ? "green" : "red",
                fontWeight: "bold",
              }}
            >
              {item.descricao} - {item.status}
            </Text>
            <View style={styles.acoes}>
              <TouchableOpacity
                style={styles.botaoAcao}
                onPress={() => deletarTarefa(item.id)}
              >
                <Text style={styles.textoAcao}>🚫 Deletar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.botaoAcao}
                onPress={() =>
                  navigation.navigate("EditarTarefa", { tarefa: item })
                }
              >
                <Text style={styles.textoAcao}>✏️ Editar</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
      <TouchableOpacity
        style={styles.botaoNovaTarefa}
        onPress={() => navigation.navigate("NovaTarefa")}
      >
        <Text style={styles.textoBotao}>+ Nova Tarefa</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f5f5f5",
  },
  filtroContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },
  botaoFiltro: {
    flex: 1,
    marginHorizontal: 5,
    paddingVertical: 10,
    backgroundColor: "#ccc",
    borderRadius: 5,
    alignItems: "center",
  },
  botaoAtivo: {
    backgroundColor: "#6200ea",
  },
  textoBotao: {
    color: "#fff",
    fontWeight: "bold",
  },
  item: {
    backgroundColor: "#fff",
    padding: 15,
    marginVertical: 5,
    borderRadius: 5,
    elevation: 2,
  },
  acoes: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
  botaoAcao: {
    padding: 10,
    backgroundColor: "#e0e0e0",
    borderRadius: 5,
  },
  textoAcao: {
    fontWeight: "bold",
    color: "#333",
  },
  botaoNovaTarefa: {
    marginTop: 20,
    paddingVertical: 15,
    backgroundColor: "#6200ea",
    borderRadius: 5,
    alignItems: "center",
  },
});

export default HomeScreen;
