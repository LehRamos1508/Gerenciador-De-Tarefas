import React, { useState } from "react";
import {
  View,
  TextInput,
  Button,
  Text,
  Picker,
  ScrollView,
} from "react-native";
import axios from "axios";
import { globalStyles } from "../styles";

const API_URL = "http://10.68.152.255:3000";

const NovaTarefaScreen = ({ navigation }) => {
  const [id, setId] = useState(Math.floor(Math.random() * 1000));
  const [descricao, setDescricao] = useState("");
  const [status, setStatus] = useState("pendente");
  const [error, setError] = useState("");

  const adicionarTarefa = () => {
    if (!descricao.trim()) {
      setError("Descrição não pode estar vazia.");
      return;
    }
    axios
      .post(`${API_URL}/tarefas`, { id, descricao, status })
      .then(() => {
        setError("");
        navigation.goBack();
      })
      .catch((error) => {
        setError("Erro ao adicionar tarefa: " + error.message);
        console.error(error);
      });
  };

  return (
    <ScrollView style={globalStyles.container}>
      <Text style={globalStyles.title}>Nova Tarefa</Text>
      {error ? <Text style={globalStyles.error}>{error}</Text> : null}
      <View style={globalStyles.formGroup}>
        <Text style={globalStyles.label}>Descrição da Tarefa:</Text>
        <TextInput
          style={globalStyles.input}
          placeholder="Digite a descrição da tarefa"
          value={descricao}
          onChangeText={setDescricao}
        />
      </View>
      <View style={globalStyles.formGroup}>
        <Text style={globalStyles.label}>Status:</Text>
        <Picker
          selectedValue={status}
          onValueChange={(itemValue) => setStatus(itemValue)}
          style={globalStyles.picker}
        >
          <Picker.Item label="Pendente" value="pendente" />
          <Picker.Item label="Feito" value="feito" />
        </Picker>
      </View>
      <Button
        title="Salvar"
        onPress={adicionarTarefa}
        style={globalStyles.button}
      />
    </ScrollView>
  );
};

export default NovaTarefaScreen;
